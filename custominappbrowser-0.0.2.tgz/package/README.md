# custominappbrowser

This is a copy of the inappbrowser from capacitor

## Install

```bash
npm install custominappbrowser
npx cap sync
```

## API

<docgen-index>

* [`echo(...)`](#echo)
* [`openUrl(...)`](#openurl)

</docgen-index>

<docgen-api>
<!--Update the source file JSDoc comments and rerun docgen to update the docs below-->

### echo(...)

```typescript
echo(options: { value: string; }) => Promise<{ value: string; }>
```

| Param         | Type                            |
| ------------- | ------------------------------- |
| **`options`** | <code>{ value: string; }</code> |

**Returns:** <code>Promise&lt;{ value: string; }&gt;</code>

--------------------


### openUrl(...)

```typescript
openUrl(options: { url: string; }) => Promise<{ success: boolean; }>
```

| Param         | Type                          |
| ------------- | ----------------------------- |
| **`options`** | <code>{ url: string; }</code> |

**Returns:** <code>Promise&lt;{ success: boolean; }&gt;</code>

--------------------

</docgen-api>
